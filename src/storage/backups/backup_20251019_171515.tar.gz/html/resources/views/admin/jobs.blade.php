@extends('admin.layouts.app')

@section('content')
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h4">Failed Jobs</h1>
    <form method="POST" action="{{ route('admin.jobs.retry_all') }}">
      @csrf
      <button class="btn btn-sm btn-primary">Retry All Failed Jobs</button>
    </form>
  </div>
  <div class="table-responsive">
    <table class="table table-sm table-striped align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Connection</th>
          <th>Queue</th>
          <th>Failed At</th>
          <th width="140">Actions</th>
        </tr>
      </thead>
      <tbody>
        @forelse($failed as $job)
        <tr>
          <td class="font-monospace">{{ $job->id }}</td>
          <td>{{ $job->connection }}</td>
          <td>{{ $job->queue }}</td>
          <td>{{ $job->failed_at }}</td>
          <td>
            <div class="d-flex gap-2">
              <form method="POST" action="{{ route('admin.jobs.retry', $job->id) }}">
                @csrf
                <button class="btn btn-sm btn-outline-primary">Retry</button>
              </form>
              <form method="POST" action="{{ route('admin.jobs.delete', $job->id) }}" onsubmit="return confirm('Delete failed job #{{ $job->id }}?');">
                @csrf
                @method('DELETE')
                <button class="btn btn-sm btn-outline-danger">Delete</button>
              </form>
            </div>
          </td>
        </tr>
        @empty
        <tr>
          <td colspan="5" class="text-center text-muted">No failed jobs</td>
        </tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection


