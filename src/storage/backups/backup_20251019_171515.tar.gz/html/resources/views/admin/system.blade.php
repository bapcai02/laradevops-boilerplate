@extends('admin.layouts.app')

@section('content')
<div class="container-fluid">
  <h1 class="h4 mb-3">System</h1>

  <div class="row g-3">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header">Disk usage (df -h)</div>
        <div class="card-body"><pre class="mb-0">{{ $df }}</pre></div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header">Memory (free -m)</div>
        <div class="card-body"><pre class="mb-0">{{ $free }}</pre></div>
      </div>
    </div>
  </div>

  <div class="row g-3 mt-1">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header">Uptime</div>
        <div class="card-body">{{ $uptime ?: 'N/A' }}</div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header">Current user</div>
        <div class="card-body">{{ $user }}</div>
      </div>
    </div>
  </div>
</div>
@endsection


