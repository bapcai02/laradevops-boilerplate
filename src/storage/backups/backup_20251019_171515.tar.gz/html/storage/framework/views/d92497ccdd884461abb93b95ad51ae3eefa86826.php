<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f5f7fb; }
        .sidebar { width: 240px; min-height: 100vh; background:#0f172a; }
        .sidebar a { color: #cbd5e1; text-decoration: none; display:block; padding:.75rem 1rem; border-radius:.5rem; }
        .sidebar a.active, .sidebar a:hover { background:#1e293b; color:#fff; }
    </style>
  </head>
  <body>
    <div class="d-flex">
      <aside class="sidebar p-3">
        <div class="text-white fw-semibold mb-3">DevOps Admin</div>
        <nav class="nav flex-column gap-1">
          <a class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
          <a class="<?php echo e(request()->routeIs('admin.logs*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.logs')); ?>">Logs</a>
          <a class="<?php echo e(request()->routeIs('admin.jobs*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.jobs')); ?>">Jobs</a>
          <a class="<?php echo e(request()->routeIs('admin.deploy*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.deploy')); ?>">Deploy</a>
          <a class="<?php echo e(request()->routeIs('admin.cache*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.cache')); ?>">Cache</a>
          <a class="<?php echo e(request()->routeIs('admin.system') ? 'active' : ''); ?>" href="<?php echo e(route('admin.system')); ?>">System</a>
        </nav>
      </aside>
      <main class="flex-grow-1 p-4">
        <?php echo $__env->yieldContent('content'); ?>
      </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
 </html>


<?php /**PATH /var/www/html/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>