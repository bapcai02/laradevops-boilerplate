<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h4">Failed Jobs</h1>
    <form method="POST" action="<?php echo e(route('admin.jobs.retry_all')); ?>">
      <?php echo csrf_field(); ?>
      <button class="btn btn-sm btn-primary">Retry All Failed Jobs</button>
    </form>
  </div>
  <div class="table-responsive">
    <table class="table table-sm table-striped align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Connection</th>
          <th>Queue</th>
          <th>Failed At</th>
          <th width="140">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $failed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="font-monospace"><?php echo e($job->id); ?></td>
          <td><?php echo e($job->connection); ?></td>
          <td><?php echo e($job->queue); ?></td>
          <td><?php echo e($job->failed_at); ?></td>
          <td>
            <div class="d-flex gap-2">
              <form method="POST" action="<?php echo e(route('admin.jobs.retry', $job->id)); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-sm btn-outline-primary">Retry</button>
              </form>
              <form method="POST" action="<?php echo e(route('admin.jobs.delete', $job->id)); ?>" onsubmit="return confirm('Delete failed job #<?php echo e($job->id); ?>?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-outline-danger">Delete</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="5" class="text-center text-muted">No failed jobs</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/jobs.blade.php ENDPATH**/ ?>