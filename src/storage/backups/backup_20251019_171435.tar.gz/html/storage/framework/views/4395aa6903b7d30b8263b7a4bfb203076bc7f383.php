<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h5 mb-0">Log Details</h1>
    <a class="btn btn-sm btn-secondary" href="<?php echo e(route('admin.logs')); ?>">Back</a>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <div class="mb-2">
        <span class="badge <?php echo e($entry['level']==='ERROR' ? 'bg-danger' : ($entry['level']==='WARNING' ? 'bg-warning text-dark' : 'bg-secondary')); ?>"><?php echo e($entry['level']); ?></span>
        <span class="text-muted ms-2"><?php echo e($entry['datetime']); ?></span>
      </div>
      <div class="mb-3 fw-semibold"><?php echo e($entry['message']); ?></div>
      <pre class="bg-dark text-white p-3" style="white-space: pre-wrap;"><?php echo e($entry['body']); ?></pre>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/log_show.blade.php ENDPATH**/ ?>