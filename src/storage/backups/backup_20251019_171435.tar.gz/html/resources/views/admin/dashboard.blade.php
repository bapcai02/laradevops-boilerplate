@extends('admin.layouts.app')

@section('content')
<div class="container-fluid">
  <h1 class="h4 mb-4">Dashboard</h1>
  <div class="row g-3">
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="small text-muted">PHP version</div>
          <div class="fs-5 fw-semibold">{{ $phpVersion }}</div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="small text-muted">Laravel version</div>
          <div class="fs-5 fw-semibold">{{ $laravelVersion }}</div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="small text-muted">Memory usage</div>
          <div class="fs-5 fw-semibold">{{ $memoryUsageMb }} MB</div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="small text-muted">Uptime</div>
          <div class="fs-6">{{ $uptime ?: 'N/A' }}</div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection


