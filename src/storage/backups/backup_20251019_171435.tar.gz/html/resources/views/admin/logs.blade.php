@extends('admin.layouts.app')

@section('content')
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h4 mb-0">Logs</h1>
    <form method="POST" action="{{ route('admin.logs.clear') }}">
      @csrf
      <button class="btn btn-sm btn-danger">Clear Logs</button>
    </form>
  </div>

  <div class="table-responsive">
    <table class="table table-sm table-hover align-middle">
      <thead>
        <tr>
          <th style="width: 120px;">Datetime</th>
          <th style="width: 90px;">Level</th>
          <th>Message</th>
          <th style="width: 90px;">Action</th>
        </tr>
      </thead>
      <tbody>
        @forelse($entries as $e)
        <tr>
          <td class="text-nowrap font-monospace">{{ $e['datetime'] }}</td>
          <td><span class="badge {{ $e['level']==='ERROR' ? 'bg-danger' : ($e['level']==='WARNING' ? 'bg-warning text-dark' : 'bg-secondary') }}">{{ $e['level'] }}</span></td>
          <td class="text-truncate" style="max-width: 600px;">{{ $e['message'] }}</td>
          <td><a class="btn btn-sm btn-outline-primary" href="{{ route('admin.logs.show',$e['id']) }}">Details</a></td>
        </tr>
        @empty
        <tr>
          <td colspan="4" class="text-center text-muted">No logs</td>
        </tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection


