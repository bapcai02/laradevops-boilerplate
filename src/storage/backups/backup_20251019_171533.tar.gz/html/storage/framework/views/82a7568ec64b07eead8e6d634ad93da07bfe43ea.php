<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h4">Cache</h1>
    <form method="POST" action="<?php echo e(route('admin.cache.clear_all')); ?>">
      <?php echo csrf_field(); ?>
      <button class="btn btn-sm btn-warning">Clear All Cache</button>
    </form>
  </div>
  <div class="table-responsive">
    <table class="table table-sm table-striped align-middle">
      <thead>
        <tr>
          <th>Key</th>
          <th width="120">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="font-monospace"><?php echo e(is_string($key) ? $key : json_encode($key)); ?></td>
          <td>
            <form method="POST" action="<?php echo e(route('admin.cache.clear', is_string($key)? $key : base64_encode(json_encode($key)))); ?>">
              <?php echo csrf_field(); ?>
              <button class="btn btn-sm btn-outline-danger">Clear Key</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="2" class="text-center text-muted">No keys</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/cache.blade.php ENDPATH**/ ?>