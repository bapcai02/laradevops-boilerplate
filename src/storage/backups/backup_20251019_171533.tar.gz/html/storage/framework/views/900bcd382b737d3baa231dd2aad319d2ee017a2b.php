<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h4 mb-0">Deploy</h1>
    <form method="POST" action="<?php echo e(route('admin.deploy.run')); ?>">
      <?php echo csrf_field(); ?>
      <button class="btn btn-sm btn-success">Run Deployment</button>
    </form>
  </div>

  <?php if(!empty($history)): ?>
  <div class="card shadow-sm mb-3">
    <div class="card-header">Deploy History</div>
    <div class="table-responsive">
      <table class="table table-sm table-striped mb-0">
        <thead>
          <tr>
            <th>Version</th>
            <th>Status</th>
            <th>Started/Finished (UTC)</th>
            <th>Duration</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="font-monospace"><?php echo e($h['id'] ?? ''); ?></td>
            <td>
              <span class="badge <?php echo e(($h['status'] ?? '')==='success' ? 'bg-success' : ((($h['status'] ?? '')==='fail') ? 'bg-danger' : 'bg-secondary')); ?>">
                <?php echo e(strtoupper($h['status'] ?? 'unknown')); ?>

              </span>
            </td>
            <td class="text-nowrap">
              <?php if(($h['status'] ?? '')==='started'): ?>
                <?php echo e($h['started_at'] ?? ''); ?>

              <?php else: ?>
                <?php echo e($h['finished_at'] ?? ''); ?>

              <?php endif; ?>
            </td>
            <td><?php echo e($h['duration_sec'] ?? '-'); ?>s</td>
            <td>
              <?php if(isset($h['log_file'])): ?>
                <a href="<?php echo e(route('admin.deploy.logs')); ?>?version=<?php echo e($h['id']); ?>&html=1" target="_blank" class="btn btn-sm btn-outline-primary">View Log</a>
              <?php else: ?>
                <span class="text-muted">No log</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

  <div class="card shadow-sm">
    <div class="card-header d-flex align-items-center justify-content-between">
      <span>Deploy Output (live)</span>
      <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('admin.deploy.logs')); ?>" target="_blank">Open raw log</a>
    </div>
    <div class="card-body p-0">
      <iframe src="<?php echo e(route('admin.deploy.logs')); ?>?html=1" style="width:100%; height:70vh; border:0; background:#0b1220;"></iframe>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/deploy.blade.php ENDPATH**/ ?>