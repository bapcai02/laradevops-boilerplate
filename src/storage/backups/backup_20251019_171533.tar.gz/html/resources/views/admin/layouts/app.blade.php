<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f5f7fb; }
        .sidebar { width: 240px; min-height: 100vh; background:#0f172a; }
        .sidebar a { color: #cbd5e1; text-decoration: none; display:block; padding:.75rem 1rem; border-radius:.5rem; }
        .sidebar a.active, .sidebar a:hover { background:#1e293b; color:#fff; }
    </style>
  </head>
  <body>
    <div class="d-flex">
      <aside class="sidebar p-3">
        <div class="text-white fw-semibold mb-3">DevOps Admin</div>
        <nav class="nav flex-column gap-1">
          <a class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}" href="{{ route('admin.dashboard') }}">Dashboard</a>
          <a class="{{ request()->routeIs('admin.logs*') ? 'active' : '' }}" href="{{ route('admin.logs') }}">Logs</a>
          <a class="{{ request()->routeIs('admin.jobs*') ? 'active' : '' }}" href="{{ route('admin.jobs') }}">Jobs</a>
          <a class="{{ request()->routeIs('admin.deploy*') ? 'active' : '' }}" href="{{ route('admin.deploy') }}">Deploy</a>
          <a class="{{ request()->routeIs('admin.cache*') ? 'active' : '' }}" href="{{ route('admin.cache') }}">Cache</a>
          <a class="{{ request()->routeIs('admin.system') ? 'active' : '' }}" href="{{ route('admin.system') }}">System</a>
        </nav>
      </aside>
      <main class="flex-grow-1 p-4">
        @yield('content')
      </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
 </html>


