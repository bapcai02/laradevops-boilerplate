@extends('admin.layouts.app')

@section('content')
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h4 mb-0">Deploy</h1>
    <form method="POST" action="{{ route('admin.deploy.run') }}">
      @csrf
      <button class="btn btn-sm btn-success">Run Deployment</button>
    </form>
  </div>

  @if(!empty($history))
  <div class="card shadow-sm mb-3">
    <div class="card-header">Deploy History</div>
    <div class="table-responsive">
      <table class="table table-sm table-striped mb-0">
        <thead>
          <tr>
            <th>Version</th>
            <th>Status</th>
            <th>Started/Finished (UTC)</th>
            <th>Duration</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          @foreach($history as $h)
          <tr>
            <td class="font-monospace">{{ $h['id'] ?? '' }}</td>
            <td>
              <span class="badge {{ ($h['status'] ?? '')==='success' ? 'bg-success' : ((($h['status'] ?? '')==='fail') ? 'bg-danger' : 'bg-secondary') }}">
                {{ strtoupper($h['status'] ?? 'unknown') }}
              </span>
            </td>
            <td class="text-nowrap">
              @if(($h['status'] ?? '')==='started')
                {{ $h['started_at'] ?? '' }}
              @else
                {{ $h['finished_at'] ?? '' }}
              @endif
            </td>
            <td>{{ $h['duration_sec'] ?? '-' }}s</td>
            <td>
              @if(isset($h['log_file']))
                <a href="{{ route('admin.deploy.logs') }}?version={{ $h['id'] }}&html=1" target="_blank" class="btn btn-sm btn-outline-primary">View Log</a>
              @else
                <span class="text-muted">No log</span>
              @endif
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
  @endif

  <div class="card shadow-sm">
    <div class="card-header d-flex align-items-center justify-content-between">
      <span>Deploy Output (live)</span>
      <a class="btn btn-sm btn-outline-secondary" href="{{ route('admin.deploy.logs') }}" target="_blank">Open raw log</a>
    </div>
    <div class="card-body p-0">
      <iframe src="{{ route('admin.deploy.logs') }}?html=1" style="width:100%; height:70vh; border:0; background:#0b1220;"></iframe>
    </div>
  </div>
</div>
@endsection


