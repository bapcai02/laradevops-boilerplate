@extends('admin.layouts.app')

@section('content')
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h4">Cache</h1>
    <form method="POST" action="{{ route('admin.cache.clear_all') }}">
      @csrf
      <button class="btn btn-sm btn-warning">Clear All Cache</button>
    </form>
  </div>
  <div class="table-responsive">
    <table class="table table-sm table-striped align-middle">
      <thead>
        <tr>
          <th>Key</th>
          <th width="120">Actions</th>
        </tr>
      </thead>
      <tbody>
        @forelse($keys as $key)
        <tr>
          <td class="font-monospace">{{ is_string($key) ? $key : json_encode($key) }}</td>
          <td>
            <form method="POST" action="{{ route('admin.cache.clear', is_string($key)? $key : base64_encode(json_encode($key))) }}">
              @csrf
              <button class="btn btn-sm btn-outline-danger">Clear Key</button>
            </form>
          </td>
        </tr>
        @empty
        <tr><td colspan="2" class="text-center text-muted">No keys</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection


