<?php

namespace App\Admin\Controllers;

use Illuminate\Http\Request;

class DashboardController
{
    public function index()
    {
        $phpVersion = PHP_VERSION;
        $laravelVersion = app()->version();
        $memoryUsageMb = round(memory_get_usage(true) / 1024 / 1024, 2);
        $uptime = function_exists('shell_exec') ? trim((string) @shell_exec('uptime -p')) : null;

        return view('admin.dashboard', compact('phpVersion', 'laravelVersion', 'memoryUsageMb', 'uptime'));
    }
}


