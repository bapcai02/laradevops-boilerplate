<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <h1 class="h4 mb-3">System</h1>

  <div class="row g-3">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header">Disk usage (df -h)</div>
        <div class="card-body"><pre class="mb-0"><?php echo e($df); ?></pre></div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header">Memory (free -m)</div>
        <div class="card-body"><pre class="mb-0"><?php echo e($free); ?></pre></div>
      </div>
    </div>
  </div>

  <div class="row g-3 mt-1">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header">Uptime</div>
        <div class="card-body"><?php echo e($uptime ?: 'N/A'); ?></div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header">Current user</div>
        <div class="card-body"><?php echo e($user); ?></div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/system.blade.php ENDPATH**/ ?>