<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h4 mb-0">Logs</h1>
    <form method="POST" action="<?php echo e(route('admin.logs.clear')); ?>">
      <?php echo csrf_field(); ?>
      <button class="btn btn-sm btn-danger">Clear Logs</button>
    </form>
  </div>

  <div class="table-responsive">
    <table class="table table-sm table-hover align-middle">
      <thead>
        <tr>
          <th style="width: 120px;">Datetime</th>
          <th style="width: 90px;">Level</th>
          <th>Message</th>
          <th style="width: 90px;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="text-nowrap font-monospace"><?php echo e($e['datetime']); ?></td>
          <td><span class="badge <?php echo e($e['level']==='ERROR' ? 'bg-danger' : ($e['level']==='WARNING' ? 'bg-warning text-dark' : 'bg-secondary')); ?>"><?php echo e($e['level']); ?></span></td>
          <td class="text-truncate" style="max-width: 600px;"><?php echo e($e['message']); ?></td>
          <td><a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.logs.show',$e['id'])); ?>">Details</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="4" class="text-center text-muted">No logs</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/logs.blade.php ENDPATH**/ ?>